<?php

return array(
    'markdown.yes'                            => 'Yes',
    'markdown.no'                             => 'No',
    'markdown.dialog.blank'                   => 'Open in a new tab?',
    'markdown.toolbar.button.blockquote'      => 'Blockquote',
    'markdown.toolbar.button.horizontal-rule' => 'Horizontal rule',
    'markdown.toolbar.button.heading.4'       => 'Heading 4',
    'markdown.toolbar.button.heading.5'       => 'Heading 5',
    'markdown.toolbar.button.heading.6'       => 'Heading 6',
    'markdown.toolbar.button.invisibles'      => 'Show hidden characters',
    'markdown.toolbar.button.pagelink'        => 'Link to a page of the website',
    'markdown.toolbar.button.image'           => 'Insert an image',
    'markdown.toolbar.button.file'            => 'Insert a downloadable file',
    'markdown.toolbar.button.strikethrough'   => 'Strikethrough',
);