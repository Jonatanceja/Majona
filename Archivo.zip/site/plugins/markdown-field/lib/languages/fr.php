<?php

return array(
    'markdown.yes'                            => 'Yes',
    'markdown.no'                             => 'No',
    'markdown.dialog.blank'                   => 'Ouvrir dans un nouvel onglet ?',
    'markdown.toolbar.button.blockquote'      => 'Citation',
    'markdown.toolbar.button.horizontal-rule' => 'Séparateur horizontal',
    'markdown.toolbar.button.heading.4'       => 'Titre 4',
    'markdown.toolbar.button.heading.5'       => 'Titre 5',
    'markdown.toolbar.button.heading.6'       => 'Titre 6',
    'markdown.toolbar.button.invisibles'      => 'Afficher les caractères masqués',
    'markdown.toolbar.button.pagelink'        => 'Lien vers une page du site',
    'markdown.toolbar.button.image'           => 'Insérer une image',
    'markdown.toolbar.button.file'            => 'Insérer un fichier téléchargeable',
    'markdown.toolbar.button.strikethrough'   => 'Texte barré',
);