<?php

return array(
    'markdown.yes'                            => 'Ja',
    'markdown.no'                             => 'Nein',
    'markdown.dialog.blank'                   => 'In neuem Tab öffnen?',
    'markdown.toolbar.button.blockquote'      => 'Zitat',
    'markdown.toolbar.button.horizontal-rule' => 'Horizontale Linie',
    'markdown.toolbar.button.heading.4'       => 'Überschrift 4',
    'markdown.toolbar.button.heading.5'       => 'Überschrift 5',
    'markdown.toolbar.button.heading.6'       => 'Überschrift 6',
    'markdown.toolbar.button.invisibles'      => 'Weißraum anzeigen',
    'markdown.toolbar.button.pagelink'        => 'Link zu einer Seite der Website',
    'markdown.toolbar.button.image'           => 'Bild einfügen',
    'markdown.toolbar.button.file'            => 'Datei-Download einfügen',
    'markdown.toolbar.button.strikethrough'   => 'Durchgestrichener Text',
);
