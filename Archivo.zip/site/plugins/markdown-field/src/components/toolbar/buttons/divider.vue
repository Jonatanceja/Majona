<template>
    <span class="k-toolbar-divider" />
</template>

<script>export default {};</script>
