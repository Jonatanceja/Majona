module.exports = {
  theme: {
    extend: {
      colors: {
        'eba-blue': '0F1820',
      }
    }
  },
  variants: {},
  plugins: []
}
