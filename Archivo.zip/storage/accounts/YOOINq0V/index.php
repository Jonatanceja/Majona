<?php

return [
    'email' => 'jonatanjonas@gmail.com',
    'language' => 'es_ES',
    'name' => '',
    'role' => 'admin'
];