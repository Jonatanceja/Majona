<!doctype html>
<html lang="e">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo b($site->title()); ?> | <?php echo b($page->title()); ?></title>

    <link rel="stylesheet" href="<?php echo b(mix('css/app.css')); ?>" />
    <style>
        body{ position:absolute;top:0;left:0;right:0;bottom:0; }
        body > .preventive{ position:absolute;top:50%;-webkit-transform:translateY(-50%);-moz-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);width:100%; }
        body > .preventive img{ display:block;margin:0 auto;max-width:250px;width:35%; }
    </style>
</head>
<body>
    <nav class="flex items-center justify-between flex-wrap bg-transparent p-6 z-50 fixed w-full">
        <div class="container mx-auto flex flex-wrap items-center">
        <div class="flex items-center flex-shrink-0 text-white mr-6">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 326.54 110.08"><defs><style>.cls-1{fill:#fff;}.cls-2{fill:#f40000;}</style></defs><title>eba</title><g id="Capa_2" data-name="Capa 2"><g id="Capa_1-2" data-name="Capa 1"><path class="cls-1" d="M36.84,108.05C13,108.05,0,92.16,0,70.35,0,50,13.43,33.08,37,33.08c21.09,0,33.23,13,33.23,34.23,0,1.45,0,5.35-.15,6.79H12.86C13,86.24,22.39,96.21,38,96.21c15,0,22-4.77,28.89-9.25V99.53C61.1,103.14,52,108.05,36.84,108.05ZM57.93,63.27c0-10.69-8-19.07-21.09-19.07S14.73,51.71,13.58,63.27Z"/><path class="cls-1" d="M86.09,0H98.66V47.67c4.91-8.81,15.31-14.16,25.72-14.16,19.5,0,30.48,13,30.48,35,0,29.76-20.52,39.44-40.31,39.44a90.45,90.45,0,0,1-28.46-5.06Zm29.62,96.06c14.15,0,26.14-7.37,26.14-26.72,0-15.75-7.65-23.84-21.23-23.84-7.66,0-14.3,4.62-18.35,10.12-2.16,3-3.32,7.8-3.32,13.14V93A41.64,41.64,0,0,0,115.71,96.06Z"/><path class="cls-1" d="M241.38,36.26v68.9H228.24V97.07a33.57,33.57,0,0,1-25.14,10.84c-9.82,0-18.2-3.61-25.28-10.84a37.23,37.23,0,0,1-10.4-26.43,36.65,36.65,0,0,1,10.4-26.29c7.08-7.23,15.46-10.84,25.28-10.84A33.47,33.47,0,0,1,228.24,44.2V39ZM220.73,88.84a26,26,0,0,0,6.93-18.2,25.71,25.71,0,0,0-6.93-18.06,22.46,22.46,0,0,0-33.52,0,25.71,25.71,0,0,0-6.93,18.06,26,26,0,0,0,6.93,18.2,22.74,22.74,0,0,0,33.52,0Z"/><polygon class="cls-2" points="318.33 91.03 303.77 70.13 318.33 49.24 326.54 54.95 315.96 70.13 326.54 85.31 318.33 91.03"/><polygon class="cls-2" points="264.84 91.03 256.64 85.31 267.21 70.13 256.64 54.95 264.84 49.24 279.4 70.13 264.84 91.03"/><polygon class="cls-2" points="306.76 110.08 291.59 99.5 276.41 110.08 270.69 101.87 291.59 87.31 312.48 101.87 306.76 110.08"/><polygon class="cls-2" points="291.59 52.96 270.69 38.4 276.41 30.19 291.59 40.77 306.76 30.19 312.48 38.4 291.59 52.96"/></g></g></svg>
          <span class="font-semibold text-xl tracking-tight">Tailwind CSS</span>
        </div>
        <div class="block lg:hidden">
          <button class="flex items-center px-3 py-2 border rounded text-teal-200 border-teal-400 hover:text-white hover:border-white">
            <svg class="fill-current h-3 w-3" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><title>Menu</title><path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z"/></svg>
          </button>
        </div>
        <div class="w-full block flex-grow lg:flex lg:items-center lg:w-auto">
          <div class="text-sm text-right lg:flex-grow">
            <a href="#responsive-header" class="block mt-4 lg:inline-block lg:mt-0 text-teal-200 hover:text-white mr-4">
              Docs
            </a>
            <a href="#responsive-header" class="block mt-4 lg:inline-block lg:mt-0 text-teal-200 hover:text-white mr-4">
              Examples
            </a>
            <a href="#responsive-header" class="block mt-4 lg:inline-block lg:mt-0 text-teal-200 hover:text-white">
              Blog
            </a>
          </div>
        </div>
        </div>
      </nav>
<?php echo $__env->yieldContent('content'); ?>
<script src="<?php echo b(mix('js/app.js')); ?>"></script>
</body>
</html>
