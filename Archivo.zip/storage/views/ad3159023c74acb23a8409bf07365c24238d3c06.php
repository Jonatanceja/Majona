<?php $__env->startSection('content'); ?>

<div class="flex content-center flex-wrap bg-local bg-cover h-48 h-screen text-center" style="background-image: url('/images/front-cover.png')">
    <div class="container mx-auto p-2">
      <div class="text-white text-center p-2"><h1 class="text-6xl uppercase text-shadow" style="text-shadow: 1px 1px 2px gray">Un nuevo concepto en E-Sports</h1></div>
      <p class="text-white text-center p-2" style="text-shadow: 1px 1px 2px gray">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas varius tortor nibh, sit amet tempor nibh finibus et. Aenean eu enim justo. Vestibulum aliquam hendrerit molestie. Mauris malesuada nisi sit amet augue accumsan tincidunt. </p>
      <button class="bg-purple-700 hover:bg-purple-500 text-white font-bold py-2 my-10 mx-10 px-4 rounded text-center w-56">
        Button
      </button>
      <button class="bg-pink-700 hover:bg-pink-500 text-white font-bold py-2 my-10 mx-10 px-4 rounded text-center w-56">
        Button
      </button>
    </div>
    
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>