require('./bootstrap');

window.Vue = require('vue');

// Uncomment if you need Vue
// Vue.component('example', require('./components/Example.vue').default);
// new Vue({
//     el: '#app'
// });
