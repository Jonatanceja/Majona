window._ = require('lodash');
window.axios = require('axios');
