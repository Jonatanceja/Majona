<template>
  <div>
    <span>Example</span>
  </div>
</template>

<script>
    export default {
        
    }
</script>
